#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/json_parser.hpp>

#include <string>
#include <map>
#include <iostream>

namespace OOP
{

    namespace pt = boost::property_tree;

}
